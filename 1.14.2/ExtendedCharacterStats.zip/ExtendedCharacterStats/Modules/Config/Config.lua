------------------------------------------------------------------
-- Modules
------------------------------------------------------------------

---@class Config
local Config = ECSLoader:CreateModule("Config")
local _Config = Config.private

---@type GearInfos
local GearInfos = ECSLoader:ImportModule("GearInfos")
---@type Stats
local Stats = ECSLoader:ImportModule("Stats")
---@type Profile
local Profile = ECSLoader:ImportModule("Profile")

------------------------------------------------------------------
-- Configuration Frame
------------------------------------------------------------------

local AceGUI = LibStub("AceGUI-3.0")

-- Forward declaration
local _CreateGUI, _GeneralTab, _StatsTab

function Config.CreateWindow()
    local optionsGUI = _CreateGUI()
    LibStub("AceConfig-3.0"):RegisterOptionsTable("ECS", optionsGUI)
    ECS.configFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("ECS", "Extended Character Stats");

    local configFrame = AceGUI:Create("Frame");
    LibStub("AceConfigDialog-3.0"):SetDefaultSize("ECS", 440, 590)
    LibStub("AceConfigDialog-3.0"):Open("ECS", configFrame)
    configFrame:Hide();

    ECSConfigFrame = configFrame.frame;
    table.insert(UISpecialFrames, "ECSConfigFrame");
end

_CreateGUI = function()
    return {
        name = "Extended Character Stats",
        handler = ECS,
        type = "group",
        childGroups = "tab",
        args = {
            general_tab = _GeneralTab(),
            stats_tab = _StatsTab(),
        }
    }
end

_GeneralTab = function()
    return {
        name = "General",
        type = "group",
        order = 1,
        args = {
            generalHeader = {
                type = "header",
                order = 1,
                name = "General Settings",
            },
            statsWindowClosedOnOpen = {
                type = "toggle",
                order = 1.1,
                name = "Hide ECS when opening character tab",
                desc = "Hides the stats windows when opening the character tab.",
                width = "full",
                get = function () return ExtendedCharacterStats.general.statsWindowClosedOnOpen; end,
                set = function (_, value)
                    ExtendedCharacterStats.general.statsWindowClosedOnOpen = value
                end,
            },
            addColorsToStatTexts = {
                type = "toggle",
                order = 2,
                name = "Colorize Stats",
                desc = "Adds colors to the stats overview.",
                width = "full",
                get = function () return ExtendedCharacterStats.general.addColorsToStatTexts; end,
                set = function (_, value)
                    ExtendedCharacterStats.general.addColorsToStatTexts = value
                    Stats.RebuildStatInfos()
                end,
            },
            statColorSelection = {
                type = "select",
                order = 2.1,
                values = {
                    ["full"] = "Full",
                    ["texts"] = "Stat texts",
                    ["values"] = "Stat values",
                },
                style = "dropdown",
                disabled = function() return (not ExtendedCharacterStats.general.addColorsToStatTexts) end,
                name = "Stats colorization",
                get = function()
                    if (not ExtendedCharacterStats.general.statColorSelection) then
                        return "full"
                    else
                        return ExtendedCharacterStats.general.statColorSelection;
                    end
                end,
                set = function(_, selection)
                    ExtendedCharacterStats.general.statColorSelection = selection
                    Stats.RebuildStatInfos()
                end,
            },
            showQualityColors = {
                type = "toggle",
                order = 3,
                name = "Show Item Quality Colors",
                desc = "Shows/Hides the colored frames around equipped items.",
                width = "full",
                get = function () return ExtendedCharacterStats.general.showQualityColors; end,
                set = function (_, value)
                    GearInfos:ToggleColorFrames(value)
                    ExtendedCharacterStats.general.showQualityColors = value
                end,
            },
            qualityColorsIntensity = {
                type = "range",
                order = 4,
                name = "Quality Colors' Intensity",
                desc = "Changes the intensity of the colored frames' glow.",
                width = "double",
                min = 0.10,
                max = 1.00,
                step = 0.01,
                get = function() return ExtendedCharacterStats.general.qualityColorsIntensity; end,
                set = function (_, value)
                    ExtendedCharacterStats.general.qualityColorsIntensity = value
                    GearInfos.UpdateGearColorFrames()
                end,
            },
            headerFontSize = {
                type = "range",
                order = 5,
                name = "Header Font Size",
                desc = "Changes the font size of the headers (e.g. Melee)",
                width = "double",
                min = 8,
                max = 18,
                step = 1,
                get = function() return ExtendedCharacterStats.general.headerFontSize; end,
                set = function (_, value)
                    ExtendedCharacterStats.general.headerFontSize = value
                    Stats.RebuildStatInfos()
                end,
            },
            statFontSize = {
                type = "range",
                order = 6,
                name = "Stat Font Size",
                desc = "Changes the font size of the stat lines (e.g. Crit)",
                width = "double",
                min = 8,
                max = 18,
                step = 1,
                get = function() return ExtendedCharacterStats.general.statFontSize; end,
                set = function (_, value)
                    ExtendedCharacterStats.general.statFontSize = value
                    Stats.RebuildStatInfos()
                end,
            },
            windowWidth = {
                type = "range",
                order = 7,
                name = "Window Width",
                desc = "Changes the width of the stats window",
                width = "double",
                min = 12,
                max = 25,
                step = 0.5,
                get = function() return ExtendedCharacterStats.general.window.width / 10; end,
                set = function (_, value)
                    ExtendedCharacterStats.general.window.width = value * 10
                    Stats:UpdateWindowSize()
                end,
            },
            resetSpacer = {
                type = "description",
                order = 9,
                name = " ",
                width = "full"
            },
            reset = {
                type = "execute",
                order = 9.1,
                name = "Reset ECS",
                desc = "Restores all default values of ECS.",
                func = function(_, _)
                    Profile:Reset()
                    ReloadUI()
                end
            }
        }
    }
end

_StatsTab = function ()
    return {
        name = "Stats",
        type = "group",
        order = 2,
        args = {
            statsHeader = {
                type = "header",
                order = 1,
                name = "Stats Settings",
            },
            generalGroup = _Config:LoadGeneralSection(),
            meleeGroup = _Config:LoadMeleeSection(),
            rangeGroup = _Config:LoadRangeSection(),
            defenseGroup = _Config:LoadDefenseSection(),
            mp5Group = _Config:LoadManaSection(),
            spellSchoolGroup = _Config:SpellSchoolsSection(),
            spellGroup = _Config:LoadSpellSection(),
        }
    }
end

-- Open the configuration window
function Config:ToggleWindow()
    if (not ECSConfigFrame:IsShown()) then
        ECSConfigFrame:Show()
    else
        ECSConfigFrame:Hide()
    end
end
